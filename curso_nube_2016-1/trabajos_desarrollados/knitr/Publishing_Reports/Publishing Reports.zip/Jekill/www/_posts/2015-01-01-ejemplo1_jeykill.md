---
title: Ejemplo Publicación de Informes 3
---
A continuación la gráfica de la función seno (x) para -$\pi < x < \pi$

```r
plot(sin,-pi,pi,col = 'green')
```

<img src="https://photos-6.dropbox.com/t/2/AADiMmUmwMPAu9mFBGNqGEOIL9PdJRB7KU1-JjESeKkyRQ/12/220067773/png/32x32/1/_/1/2/unnamed-chunk-1-1.png/EO7hvaUBGOQ_IAcoBw/rOb4BhQ00LDGLmKBbJCWPAQud3QutECnMonSVW9QiCQ?size_mode=5" title="plot of chunk unnamed-chunk-1" alt="plot of chunk unnamed-chunk-1" style="display: block; margin: auto;" />

