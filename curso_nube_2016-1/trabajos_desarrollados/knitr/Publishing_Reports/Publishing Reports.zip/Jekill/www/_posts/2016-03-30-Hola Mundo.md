layout: default
title: Hola mundo!

Este es el texto del post en Jekyll.
