---
title: Ejemplo Publicación de Informes
---
A continuación la gráfica de la función seno (x) para -$\pi < x < \pi$


```r
plot(sin,-pi,pi,col = 'green')
```

<img src="figure/unnamed-chunk-1-1.png" title="plot of chunk unnamed-chunk-1" alt="plot of chunk unnamed-chunk-1" style="display: block; margin: auto;" />
